# ChatAs — Satchel AI Study Tutor

ChatAs is a study-tutor web app. The frontend sends a student's question to a
FastAPI backend, which uses the Google Gemini API to return a structured,
step-by-step explanation.

## Project files

- `index.html` — website structure and frontend JavaScript
- `style2.css` — website styling
- `main.py` — FastAPI backend and Gemini integration
- `requirements.txt` — Python dependencies
- `.env.example` — example environment-variable configuration

## Requirements

- Python 3.10 or newer
- A Google Gemini API key

## Run the backend locally

### 1. Create and activate a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure your Gemini API key

Copy `.env.example` to `.env` and add your own key:

```env
GEMINI_API_KEY=your_gemini_api_key_here
```

The current `main.py` reads environment variables using `os.environ`.
For automatic local `.env` loading, add `from dotenv import load_dotenv` and
call `load_dotenv()` before reading `GEMINI_API_KEY`.

Never commit your real `.env` file or API key to GitHub.

### 4. Start the backend

```bash
uvicorn main:app --reload --port 8000
```

Check `http://localhost:8000/health` for the health status.

## Frontend connection

The current `index.html` points to the deployed backend:

```javascript
const API_URL = "https://chatas-backend-an0u.onrender.com/api/ask";
```

For local development, change it to:

```javascript
const API_URL = "http://localhost:8000/api/ask";
```

## Deployment notes

- Set `GEMINI_API_KEY` as a secret/environment variable in your backend host.
- Configure CORS in `main.py` to allow only your actual frontend domain before
  public launch. The current code uses `allow_origins=["*"]`.
- Consider adding rate limiting before making the API publicly available.
- Never upload API keys, passwords, or private credentials to GitHub.
